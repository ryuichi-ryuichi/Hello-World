file -I README_utf8.md
