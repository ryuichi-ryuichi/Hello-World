exports.handler = async (event) => { console.log('Lambda function triggered with event:', event); return 'Hello from Lambda!'; };
